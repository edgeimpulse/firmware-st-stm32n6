 /**
  ***********************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32N6xx devices support on EWARM.
  ***********************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ************************************************************************************************/
  These packages contains the needed files to be installed in order to support STM32N6xx
  devices by EWARM9 and laters.
  
    We nform you that this package is suitable for internal & external use.
    EWARMv9_STM32N6xx_V0.6.2.exe has been digitally signed by STMicroelectronics.
  
  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed:
  ================================================================ 
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	
	2. The following items will be added :
    - Product line :STM32N657x0/STM32N647x0/STM32N655x0/STM32N645x0.
    - STM32N6570-Nucleo dedicated connection with OSPI external loader support. 
    - STM32N6570-DK dedicated connection with OSPI external loader support. 

	3. STM32N6 SVD file v0r3.
	
 PS: when using external loader on EWARM, please unselect the verify from the debug menu
	 Please note that you can run EWARMv9_STM32N6xx_V0.6.2.exe only if the uninstall is not needed.


How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32N6xx_V0.6.2.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   

 SVD files ReleaseNotes:
 =======================
	=======================================================
	STM32N6xx_v0r1:     initial release
	=======================================================
	Doc ID: RM0486 Rev 0.3 _ 17 November 2022

	Initilal release

	=======================================================
	STM32N6xx_v0r2:     Second release
	=======================================================
	Doc ID: RM0486 Rev 0.3 _ 17 November 2022

	Additional support for IPs

	=======================================================
	STM32N6_v0r3:     Update
	=======================================================
	Doc ID: RM0486 Rev 0.3 _ 17 November 2022

	Rename from STM32N6xx ==> STM32N6

	Additional support for missing IPs from IPxact
	(ipxact_230323_1841_RM0486_rev0_3_Python)

	



